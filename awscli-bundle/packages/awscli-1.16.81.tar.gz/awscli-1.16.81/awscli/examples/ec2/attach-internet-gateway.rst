**To attach an Internet gateway to your VPC**

This example attaches the specified Internet gateway to the specified VPC. If the command succeeds, no output is returned.

Command::

  aws ec2 attach-internet-gateway --internet-gateway-id igw-c0a643a9 --vpc-id vpc-a01106c2